/**
 * 
 */
/**
 * @author inndata
 *
 */
module JDBCCRUD {
	requires java.sql;
}