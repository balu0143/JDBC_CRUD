package com.jdbc.crud;


import java.sql.*;
import java.util.Scanner;


public class CrudOperations {
	
		public static void main(String[] args) throws Exception  {
			
			//Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//URL
			String  url="jdbc:mysql://localhost:3306/sandeep_test";
			
			//Username
			String username="sandeep";
			
			//Password
			String password="inndata@123!";
			
			//Get connection
			Connection con =DriverManager.getConnection(url,username,password);
	        
			//create statement
			Statement stmt =con.createStatement();
			
			//ResultSet
			ResultSet rs;
			PreparedStatement st;
	        
			//DataTypes
			String qry="";  
			int id,choice;
			String first_name,last_name,designation;
			double salary;
	        
			//Using Scanner Class
			Scanner in = new Scanner(System.in);
			Scanner str = new Scanner(System.in);
	 
			while(true)
			{
				System.out.println("JDBC CRUD Operation");
				//Add Employee Data
				System.out.println("1. Insert");
				//Update Employee Data
				System.out.println("2. Update");
				//Delete employee Data
				System.out.println("3. Delete");
				//Select All Employee Data
				System.out.println("4. Select");
				//Exit
				System.out.println("5. Exit");
				System.out.print("Enter a choice: ");
				choice = in.nextInt();
				System.out.println("-----------------------------------------");
				switch(choice){
				case 1:
					
					//insert Employee Data
					
					System.out.println("1. Insert New Data");
					System.out.println("Enter FirstName : ");
					first_name=str.nextLine();
					System.out.println("Enter LastName : ");
					last_name=str.nextLine();
					System.out.println("Enter Designation : ");
					designation=str.nextLine();
					System.out.println("Enter Salary : ");
					salary=str.nextDouble();
	                
					//Insert Query
					qry="insert into EmployeeData (FirstName,LastName,Designation,Salary) values(?,?,?,?)";
					st= con.prepareStatement(qry);
					st.setString(1, first_name);
					st.setString(2, last_name);
					st.setString(3, designation);
					st.setDouble(4, salary);
	 
					st.executeUpdate();
					System.out.println("Data Insert Success");
	 
					break;
				case 2:
					
					//update Employee Data
					
					System.out.println("2. Updating a Data");
	 
					System.out.println("Enter ID : ");
					id=in.nextInt();
					System.out.println("Enter FirstName : ");
					first_name=str.nextLine();
					System.out.println("Enter LastName : ");
					last_name=str.nextLine();
					System.out.println("Enter Designation : ");
					designation=str.nextLine();
					System.out.println("Enter Salary : ");
					salary=str.nextDouble();
	                
					//Update Query
					qry="update EmployeeData set FirstName=?,LastName=?,Designation=?,Salary=? where ID=?";
					st= con.prepareStatement(qry);
	 
					st.setString(1, first_name);
					st.setString(2, last_name);
					st.setString(3, designation);
					st.setDouble(4, salary);
					st.setInt(5, id);
					st.executeUpdate();
					System.out.println("Data Update Success");
	 
					break;
				case 3:
					
					//delete Employee Data
					
					System.out.println("3. Deleting a Data");
					System.out.println("Enter ID : ");
					id=in.nextInt();
	                
					//Delete Query
					qry="delete from EmployeeData where ID=?";
					st= con.prepareStatement(qry);
					st.setInt(1, id);
	 
					st.executeUpdate();
					System.out.println("Data Deleted Success");
	 
					break;
				case 4:
					
					//Select Employee Data
					
					System.out.println("4.  All Employees Data");
					qry="SELECT ID,FirstName,LastName,Designation,Salary from EmployeeData";
					rs=stmt.executeQuery(qry);
					while(rs.next())
					{
						id=rs.getInt("ID");
						first_name=rs.getString("FirstName");
						last_name=rs.getString("FirstName");
						designation=rs.getString("Designation");
						salary=rs.getDouble("Salary");
	 
						System.out.print(id+" ");
						System.out.print(first_name+" ");
						System.out.print(last_name+" ");
						System.out.print(designation+" ");
						System.out.println(salary+" ");
	 
					}
					break;
				case 5:
					System.out.println("Thank You");
					System.exit(0);
					break;
				default:
					System.out.println("Invalid Selection");
					break;
				}
				System.out.println("-----------------------------------------");
			}
		}
	 
	

}
